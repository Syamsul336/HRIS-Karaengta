# Karaengta HRIS — Design System & Style Guide

Dokumen ini berisi seluruh detail visual, token desain, komponen, dan aturan gaya yang digunakan pada halaman **dashboard.html** dan **login.html** proyek Karaengta HRIS. Gunakan sebagai referensi saat membangun halaman baru agar tetap selaras.

---

## 1. Nama Gaya

> **"Soft Modern Dashboard"** — Karaengta Edition

Karakter utama:
- Flat design, tidak ada glassmorphism atau neumorphism
- Warna solid cerah (kuning & merah tua) sebagai identitas kuat
- Banyak whitespace, terasa lapang dan bersih
- Border radius besar dan membulat
- Colored drop shadow sesuai warna komponen
- Font geometric modern: **Manrope**

---

## 2. Font

```
Font Family : Manrope (Google Fonts)
Import URL  : https://fonts.googleapis.com/css2?family=Manrope:wght@400;500;600;700;800;900&display=swap
```

| Penggunaan              | Size   | Weight |
|-------------------------|--------|--------|
| Heading H1              | 26–40px | 700–900 |
| Heading H2 (section)    | 24px   | 700    |
| Heading H3 (card title) | 16–18px | 700   |
| Body / paragraf         | 13–14px | 400–500 |
| Label uppercase         | 10–12px | 700, letter-spacing 0.4–1.4px |
| Angka KPI besar         | 48px   | 800, letter-spacing -2px |
| Sub-teks / muted        | 11–12px | 500    |

---

## 3. Palet Warna (Color Palette)

### Primary
```
--red          : #8D1E18   ← Warna utama brand (Falu Red / merah tua)
--red-med      : #a93226   ← Merah medium
--red-dark     : #7a1a14   ← Merah gelap (hover button)
--red-deep     : #c0392b   ← Merah cerah (KPI card 4)
```

### Accent
```
--yellow       : #FAD442   ← Bright Sun / kuning cerah (aksen utama)
--yellow-dark  : #e0bc30   ← Kuning gelap (hover yellow button)
```

### Background & Surface
```
--bg           : #FAD442   ← Background halaman utama (kuning)
--sidebar-bg   : #8D1E18   ← Background sidebar
--surface      : #FFFFFF   ← Background card / panel putih
--plan-bg      : #FFFDF0   ← Background input & planning item (krem sangat terang)
```

### Utility
```
--stat-bg      : rgba(141, 30, 24, 0.08)   ← Background stat card transparan
--border       : rgba(141, 30, 24, 0.15)   ← Border pemisah
--text-main    : #303030   ← Teks utama
--text-muted   : #BDBDBD   ← Placeholder / muted
--text-hint    : #666666   ← Sub-teks / hint
```

### KPI Card Colors (5 varian)
```
kpi-1  bg: linear-gradient(135deg, #8D1E18 → #a93226)   shadow: rgba(141,30,24,0.30)
kpi-2  bg: linear-gradient(135deg, #5a1a16 → #7a2419)   shadow: rgba(90,26,22,0.30)
kpi-3  bg: linear-gradient(135deg, #e6b800 → #FAD442)   shadow: rgba(230,184,0,0.30)
kpi-4  bg: linear-gradient(135deg, #c0392b → #e74c3c)   shadow: rgba(192,57,43,0.30)
kpi-5  bg: linear-gradient(135deg, #3d0e0a → #6b1510)   shadow: rgba(61,14,10,0.32)
```

### Topbar / Header (dark)
```
background : #1a0a09   ← Coklat-hitam sangat gelap
border-bot : rgba(250, 212, 66, 0.15)
teks biasa : rgba(255, 255, 255, 0.60)
teks bold  : #FAD442   ← Nama user
```

### Badge / Status Colors
```
badge-aktif     : bg #e8f5e9, teks #2e7d32   (hijau)
badge-resign    : bg rgba(141,30,24,.10), teks #8D1E18
badge-probation : bg #fef3e2, teks #854d0e   (oranye)
badge-contract  : bg #e8f0fe, teks #1d4e89   (biru)
badge-sp1       : bg #fef3e2, teks #854d0e
badge-sp2       : bg rgba(141,30,24,.10), teks #8D1E18
badge-yellow    : bg #FFFDF0, teks #7a5200
badge-gray      : bg rgba(141,30,24,.08), teks #8D1E18
```

---

## 4. Spacing & Layout

### Ukuran Struktur Utama
```
Sidebar width  : 210px
Header height  : 54px
Main padding   : 32px
Card padding   : 24px
```

### Border Radius
```
Card besar / KPI     : 20px
Card medium          : 16–20px
Button               : 10px
Input                : 10px
Badge / pill         : 20px (full round)
Avatar / icon box    : 9–14px
Tab                  : 9–12px
```

### Gap / Spacing
```
Antar KPI card    : 20px
Antar card grid   : 20px
Padding sidebar   : 16–18px (horizontal), 12–16px (vertikal)
Gap item nav      : 3px margin-bottom
```

---

## 5. Komponen UI

### Sidebar
- Background: `#8D1E18`
- Logo: teks `#FAD442`, weight 900, letter-spacing 3px, uppercase
- Nav item normal: teks `rgba(255,255,255,.65)`, icon `rgba(255,255,255,.55)`
- Nav item aktif: bg `#FAD442`, teks & icon `#8D1E18`, border-radius 12px, dot indicator bulat kecil di kanan
- Nav item hover: bg `rgba(250,212,66,.15)`
- Upgrade/logout box: bg `rgba(0,0,0,0.18)`, border-radius 14px

### Header / Top Bar
- Background: `#1a0a09` (gelap)
- Border bawah: `1px solid rgba(250,212,66,0.15)`
- Shadow: `0 2px 20px rgba(0,0,0,0.25)`
- Greeting: `rgba(255,255,255,0.60)`, nama user `#FAD442` weight 800
- Avatar: bg `#FAD442`, teks `#8D1E18`, border-radius 9px
- User badge: bg `rgba(255,255,255,0.08)`, border `rgba(255,255,255,0.12)`, border-radius 12px

### KPI Stat Cards
- Border-radius: 20px
- Min-height: 148px
- Overflow: hidden
- Ada garis aksen vertikal kiri: `4px × 32px`, bg `rgba(255,255,255,0.50)`
- Ada icon box kanan atas: `38×38px`, bg `rgba(255,255,255,0.15)`, border-radius 12px
- Angka: 48px, weight 800, warna putih (kecuali kpi-3 gelap)
- Label: 13px, weight 600, `rgba(255,255,255,0.75)`
- Sub-teks: 11px, weight 500, `rgba(255,255,255,0.55)`
- **Hover**: hanya `translateY(-6px)`, transition `0.25s ease` — simpel, tidak ada efek lain

### Card Putih (Content Card)
- Background: `#FFFFFF`
- Border-radius: 20px
- Padding: 24px
- Shadow: `0 4px 20px rgba(141,30,24,0.08)`
- Border: `1px solid rgba(141,30,24,0.07)`
- Hover: `box-shadow: 0 8px 32px rgba(141,30,24,0.12)`

### Tabel
- Header: bg `#8D1E18`, teks putih, weight 600, 12px
- Baris ganjil: bg `#FFFDF0`
- Baris genap: bg `#FFFFFF`
- Hover baris: bg `rgba(250,212,66,0.25)`
- Border: `1px solid rgba(141,30,24,0.12)`
- Border-radius tabel: 16px + overflow hidden

### Button
```
Primary   : bg #8D1E18, teks putih, hover bg #7a1a14
Secondary : bg #FAD442, teks #8D1E18, hover bg #e0bc30
Ghost     : border 1.5px solid #8D1E18, teks #8D1E18, hover bg rgba(141,30,24,.06)
```
- Border-radius: 10px
- Padding: 8–12px × 18px
- Font: Manrope weight 600–700, 13–14px

### Input / Form
- Background: `#FFFDF0`
- Border: `1.5px solid rgba(141,30,24,0.18)`
- Focus border: `var(--red)` + `box-shadow 0 0 0 3px rgba(141,30,24,0.08)`
- Border-radius: 10px
- Placeholder: `#BDBDBD`
- Font: Manrope 13.5px weight 500

### Tab (Toggle)
- Container: bg `rgba(141,30,24,0.18)`, border-radius 12px, padding 4px
- Tab aktif: bg `#FFFFFF`, teks `#8D1E18`, shadow `0 2px 8px rgba(141,30,24,0.15)`
- Tab tidak aktif: teks `rgba(141,30,24,0.70)`, hover bg `rgba(141,30,24,0.10)`
- Font: 13px weight 700

### Progress Bar
- Track: bg `rgba(141,30,24,0.10)`, height 5px, border-radius 99px
- Fill: bg `#8D1E18` (default), animasi `width 0.75s cubic-bezier(.22,.68,0,1.2)` dari kiri

### Bar Chart
- Container height: 120px
- Bar: border-radius 6px 6px 0 0, animasi tumbuh dari bawah (`height: 0 → target`)
- Grid lines: `repeating-linear-gradient` horizontal, `rgba(141,30,24,0.07)`
- Stagger animasi per bar: 80ms

---

## 6. Animasi & Transisi

### Keyframes yang Digunakan
```css
slideUp   : opacity 0 + translateY(28px) → opacity 1 + translateY(0)
slideRight: opacity 0 + translateX(-20px) → 100%
countUp   : opacity 0 + translateY(12px) → 100%
cardIn    : opacity 0 + translateY(24px) scale(0.97) → 100%   [login card]
dotBounce : scale 0.7 opacity .4 → scale 1.2 opacity 1        [loading dots]
loadingPulse: scale 1 → 1.08 → 1                              [loading icon]
```

### Easing Utama
```
cubic-bezier(.22, .68, 0, 1.2)  ← "spring" — untuk card muncul & count-up
ease                             ← untuk hover sederhana
```

### Stagger Delay Classes
```
.delay-1 → 0.05s
.delay-2 → 0.12s
.delay-3 → 0.19s
.delay-4 → 0.26s
.delay-5 → 0.33s
.delay-6 → 0.40s
.delay-7 → 0.47s
```

### Scroll-Reveal
- Class `.reveal` → opacity 0, translateY(24px)
- Class `.reveal.visible` → opacity 1, translateY(0)
- Transition: `0.55s cubic-bezier(.22,.68,0,1.2)`

### Count-Up Numbers
- Animasi angka dari 0 ke nilai target dengan easing cubic out
- Durasi: 800–900ms
- Dijalankan ulang setiap kali halaman/tab diaktifkan

---

## 7. Loading State

### Progress Bar (top of page)
- Posisi: fixed, top 0, full width, height 3px
- Gradient: `linear-gradient(90deg, #8D1E18, #FAD442, #c0392b)`
- Animasi shimmer bergerak horizontal terus-menerus

### Loading Overlay
- Background: `rgba(250,212,66,0.60)` + `backdrop-filter: blur(2px)`
- Logo: foto icon Karaengta, animasi `scale 1 → 1.08 → 1` (pulse)
- Label: "MEMUAT DATA", teks `#8D1E18`, uppercase, weight 700
- Dots: 3 titik bulat `#8D1E18`, animasi bounce stagger 150ms

---

## 8. Login Page — Layout

### Struktur Dua Kolom
```
Kiri (46%)  : Panel merah #8D1E18 — brand + hero text + features
Kanan (54%) : Panel kuning #FAD442 — form login
```

### Panel Kiri (Brand)
- Background: `#8D1E18`
- 2 lingkaran dekoratif: `rgba(250,212,66,0.10)` & `rgba(0,0,0,0.12)`
- Hero text: 40px weight 900, putih, highlight em: `#FAD442`
- Tag "Sistem Aktif": border `rgba(250,212,66,0.30)`, bg `rgba(250,212,66,0.15)`, dot animasi pulse

### Panel Kanan (Form)
- Background: `#FAD442`
- Dot pattern: `radial-gradient(rgba(141,30,24,0.08) 1.5px, transparent 1.5px)` ukuran 24×24px

### Login Card
- Background: `#FFFFFF`
- Max-width: 400px
- Border-radius: 24px
- Shadow: `0 12px 48px rgba(141,30,24,0.18), 0 2px 8px rgba(141,30,24,0.10)`
- Animasi masuk: `cardIn 0.5s cubic-bezier(.22,.68,0,1.2)`

### Password Eye Toggle
- Posisi: absolute kanan dalam input-wrap
- Selector penting: `.input-wrap > svg` (direct child, bukan semua SVG)
- Eye toggle: `position absolute, right 10px, top 50%`

---

## 9. Aturan Desain Umum

1. **Tidak ada efek 3D, glassmorphism, atau neumorphism** — semua flat.
2. **Colored shadow** — shadow warna mengikuti warna komponen, bukan abu-abu.
3. **Icon: SVG inline** — tidak ada emoji di UI, semua pakai SVG `stroke="currentColor"`.
4. **Hover KPI card** — hanya `translateY(-6px)`, tidak ada perubahan warna/shadow.
5. **Radius konsisten** — card 20px, button 10px, input 10px, badge 20px (pill).
6. **Teks hierarchy** — heading weight 700+, body 500, muted 400.
7. **Status di database** — selalu normalize dengan `.trim().toLowerCase()` sebelum compare.
8. **Data loading** — sequential (bukan Promise.all) + retry 2x dengan backoff 400ms.
9. **Animasi tabel** — rows fade+slide dari kiri, stagger 40ms per baris.
10. **Donut chart** — stroke-dashoffset animation, stagger 150ms per segmen.

---

## 10. CSS Variables Quick Reference

Tempel ini di bagian `:root {}` setiap halaman baru:

```css
:root {
  --red:         #8D1E18;
  --red-med:     #a93226;
  --red-dark:    #7a1a14;
  --red-deep:    #c0392b;
  --yellow:      #FAD442;
  --yellow-dark: #e0bc30;
  --bg:          #FAD442;
  --sidebar-bg:  #8D1E18;
  --surface:     #FFFFFF;
  --plan-bg:     #FFFDF0;
  --stat-bg:     rgba(141,30,24,0.08);
  --border:      rgba(141,30,24,0.15);
  --text-main:   #303030;
  --text-muted:  #BDBDBD;
  --text-hint:   #666666;
}
```

---

## 11. Prompt Template untuk Halaman Baru

Gunakan teks berikut sebagai bagian prompt saat membuat halaman baru:

```
Buat halaman dengan gaya "Soft Modern Dashboard" — Karaengta Edition.

IDENTITAS VISUAL:
- Font: Manrope (Google Fonts), weight 400–900
- Warna utama: #8D1E18 (merah tua / Falu Red)
- Warna aksen: #FAD442 (kuning Bright Sun)
- Background halaman: #FAD442
- Surface/card: #FFFFFF
- Background input: #FFFDF0

ATURAN DESAIN:
- Flat design, tidak ada glassmorphism/neumorphism
- Border radius: card 20px, button 10px, input 10px, badge 20px
- Shadow berwarna sesuai komponen (colored shadow), bukan abu-abu
- Icon: SVG inline stroke, tidak pakai emoji di UI
- Hover card: hanya translateY(-6px), transition 0.25s ease
- Tabel: header merah solid, baris alternating #FFFDF0 / #FFFFFF, hover kuning transparan
- Animasi masuk: slideUp cubic-bezier(.22,.68,0,1.2) dengan stagger delay

KOMPONEN REFERENSI:
- Button primary: bg #8D1E18, teks putih, radius 10px
- Button secondary: bg #FAD442, teks #8D1E18, radius 10px
- Input: border rgba(141,30,24,0.18), focus border #8D1E18 + ring rgba(141,30,24,0.08)
- Tab aktif: bg #FFFFFF, teks #8D1E18 | Tab tidak aktif: teks rgba(141,30,24,0.70)
- Badge: border-radius 20px, warna sesuai status (hijau=aktif, merah=resign)

Pastikan selaras dengan dashboard.html dan login.html proyek Karaengta HRIS.
```
